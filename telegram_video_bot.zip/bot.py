
from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
import json
import asyncio

API_ID = 123456  # Replace with your actual API_ID from my.telegram.org
API_HASH = "your_api_hash"  # Replace with your actual API_HASH from my.telegram.org
BOT_TOKEN = "8022407705:AAEP0SZDA_EAoTYwjunClmxCITprb7xj4Mk"

REQUIRED_CHANNELS = [
    "onlyfanzberazzers",
    "TrapLifeMatter23",
    "indenameoflove"
]

app = Client("video_lock_bot", bot_token=BOT_TOKEN, api_id=API_ID, api_hash=API_HASH)

# Load films data
def load_films():
    try:
        with open("films.json", "r") as f:
            return json.load(f)
    except:
        return {}

def save_films(data):
    with open("films.json", "w") as f:
        json.dump(data, f, indent=4)

@app.on_message(filters.command("add") & filters.private)
async def add_film(client, message: Message):
    if not message.reply_to_message or not message.reply_to_message.video:
        await message.reply("ویدیو رو فوروارد کن و زیرش /add film_name بزن.")
        return
    try:
        film_code = message.text.split(" ")[1]
    except:
        await message.reply("کد فیلم مشخص نیست. مثلاً: /add film1")
        return
    films = load_films()
    films[film_code] = message.reply_to_message.video.file_id
    save_films(films)
    await message.reply(f"✅ فیلم با کد `{film_code}` ذخیره شد.

لینک اشتراک:
https://t.me/{(await client.get_me()).username}?start={film_code}")

@app.on_message(filters.command("start") & filters.private)
async def start_handler(client, message: Message):
    films = load_films()
    args = message.text.split()
    if len(args) < 2:
        await message.reply("سلام! برای دریافت فیلم، روی لینک‌های اشتراک کلیک کن.")
        return
    film_code = args[1]
    if film_code not in films:
        await message.reply("❌ فیلم مورد نظر پیدا نشد.")
        return

    user_id = message.from_user.id
    for channel in REQUIRED_CHANNELS:
        try:
            member = await client.get_chat_member(channel, user_id)
            if member.status not in ["member", "administrator", "creator"]:
                raise Exception("Not joined")
        except:
            btns = InlineKeyboardMarkup([
                [InlineKeyboardButton("📢 عضویت در کانال‌ها", url=f"https://t.me/{channel}") for channel in REQUIRED_CHANNELS],
                [InlineKeyboardButton("🔄 بررسی عضویت", url=f"https://t.me/{(await client.get_me()).username}?start={film_code}")]
            ])
            await message.reply("⚠️ برای دریافت فیلم، ابتدا در کانال‌های زیر عضو شو:", reply_markup=btns)
            return

    sent = await message.reply_video(films[film_code])
    await asyncio.sleep(10)
    await sent.delete()

app.run()
